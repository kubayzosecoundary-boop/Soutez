SOUTĚŽE FINDER – jak z toho udělat APK
1) Nainstaluj Android Studio (https://developer.android.com/studio)
2) File > Open > vyber složku SoutezeFinder, počkej na "Gradle sync" (stáhne se samo)
3) Menu Build > Build Bundle(s) / APK(s) > Build APK(s)
4) APK najdeš v: app/build/outputs/apk/debug/app-debug.apk
5) Pošli si ho do mobilu a nainstaluj (povol "instalace z neznámých zdrojů")

--- APK přes GitHub (bez počítače) ---
1) Na github.com si založ repozitář a nahraj do něj všechny soubory z tohoto ZIPu (včetně složky .github).
2) Záložka Actions > Build APK > počkej cca 5-10 minut na zelenou fajfku.
3) Klikni na hotový běh, dole v sekci Artifacts stáhni SoutezeFinder-APK (ZIP s app-debug.apk), rozbal a nainstaluj.
