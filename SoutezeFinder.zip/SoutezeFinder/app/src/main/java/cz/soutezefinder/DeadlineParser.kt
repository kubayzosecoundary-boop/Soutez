package cz.soutezefinder

import java.text.Normalizer
import java.time.LocalDate

data class Analysis(
    val isGiveaway: Boolean,
    val deadline: LocalDate?,
    val user: String,
    val snippet: String,
    val postDate: LocalDate?,
    val caption: String
)

/** Hledá v textu příspěvku slova typu "soutěž/giveaway" a datum konce ("do 15.11.", "do 15. listopadu"...). */
object DeadlineParser {

    fun norm(s: String): String = strip(s)

    private fun strip(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    // Slova, za kterými obvykle následuje datum konce (text je bez diakritiky)
    private const val KW = "(?<![a-z])(?:do|konci|konec|ukonceni|uzaverka|deadline|until|ends?)(?![a-z])"

    private val numeric = Regex(KW + "\\D{0,18}?(\\d{1,2})\\s*[./-]\\s*(\\d{1,2})(?:\\s*[./-]\\s*(\\d{4}|\\d{2})(?![\\d:]))?")
    private val named = Regex(KW + "\\D{0,18}?(\\d{1,2})\\s*\\.?\\s*([a-z]{3,10})(?:\\s*(\\d{4}))?")
    private val giveawayWords = Regex("soutez|giveaway|vyhr|contest")
    private val userRegex = Regex("[-–]\\s*([A-Za-z0-9._]+)\\s+(?:on|dne|na)\\s")

    private fun month(word: String): Int? = when {
        word.startsWith("led") || word.startsWith("jan") -> 1
        word.startsWith("uno") || word.startsWith("feb") -> 2
        word.startsWith("bre") || word.startsWith("mar") -> 3
        word.startsWith("dub") || word.startsWith("apr") -> 4
        word.startsWith("kve") || word.startsWith("may") -> 5
        word.startsWith("cervenc") || word.startsWith("jul") -> 7
        word.startsWith("cerven") || word.startsWith("cervn") || word.startsWith("jun") -> 6
        word.startsWith("srp") || word.startsWith("aug") -> 8
        word.startsWith("zar") || word.startsWith("sep") -> 9
        word.startsWith("rij") || word.startsWith("oct") -> 10
        word.startsWith("list") || word.startsWith("nov") -> 11
        word.startsWith("pros") || word.startsWith("dec") -> 12
        else -> null
    }

    private fun build(d: Int, m: Int, y: Int?, today: LocalDate, ref: LocalDate?): LocalDate? {
        if (m !in 1..12 || d !in 1..31) return null
        if (y != null && y !in 20..2100) return null
        val year = when {
            y == null -> (ref ?: today).year
            y < 100 -> 2000 + y
            else -> y
        }
        return try {
            var r = LocalDate.of(year, m, d)
            // bez roku: datum konce je vždy po datu přidání příspěvku
            if (y == null && ref != null && r.isBefore(ref)) r = r.plusYears(1)
            r
        } catch (e: Exception) {
            null
        }
    }

    private val genericNumeric = Regex("""(?<![\d.])(\d{1,2})\s*[./]\s*(\d{1,2})(?:\s*[./]\s*(\d{4}))?(?![\d:])""")
    private val genericNamed = Regex("""(?<!\d)(\d{1,2})\s*\.?\s*((?:led|uno|bre|dub|kve|cerv|srp|zar|rij|list|pros)[a-z]*)(?:\s*(\d{4}))?""")

    private fun genericDate(s: String, today: LocalDate, ref: LocalDate?): LocalDate? {
        val base = ref ?: today
        val hits = mutableListOf<Pair<Int, LocalDate>>()
        genericNumeric.findAll(s).forEach { m ->
            val y = m.groupValues[3].ifEmpty { null }?.toInt()
            build(m.groupValues[1].toInt(), m.groupValues[2].toInt(), y, today, ref)?.let { hits.add(m.range.first to it) }
        }
        genericNamed.findAll(s).forEach { m ->
            val mo = month(m.groupValues[2]) ?: return@forEach
            val y = m.groupValues[3].ifEmpty { null }?.toInt()
            build(m.groupValues[1].toInt(), mo, y, today, ref)?.let { hits.add(m.range.first to it) }
        }
        return hits.sortedBy { it.first }.map { it.second }
            .firstOrNull { !it.isBefore(base) && !it.isAfter(base.plusDays(90)) }
    }

    private val postDateRegex = Regex("(?:dne|on)\\s+([A-Za-z]+)\\s+(\\d{1,2}),\\s*(\\d{4})")
    private val prefixRegex = Regex("""^.*?\s(?:dne|on)\s+[A-Za-z]+\s+\d{1,2},\s*\d{4}:\s*["„“”]?""")
    private val userStartRegex = Regex("^\\s*([A-Za-z0-9._]+)\\s+(?:on|dne)\\s")

    fun analyze(text: String, today: LocalDate): Analysis {
        val s = strip(text)

        // datum přidání příspěvku
        var postDate: LocalDate? = null
        postDateRegex.find(text)?.let { m ->
            val mo = month(strip(m.groupValues[1]))
            if (mo != null) {
                postDate = try {
                    LocalDate.of(m.groupValues[3].toInt(), mo, m.groupValues[2].toInt())
                } catch (e: Exception) {
                    null
                }
            }
        }

        val found = mutableListOf<Pair<Int, LocalDate>>()
        numeric.findAll(s).forEach { m ->
            val d = m.groupValues[1].toInt()
            val mo = m.groupValues[2].toInt()
            val y = m.groupValues[3].ifEmpty { null }?.toInt()
            build(d, mo, y, today, postDate)?.let { found.add(m.range.first to it) }
        }
        named.findAll(s).forEach { m ->
            val mo = month(m.groupValues[2]) ?: return@forEach
            val d = m.groupValues[1].toInt()
            val y = m.groupValues[3].ifEmpty { null }?.toInt()
            build(d, mo, y, today, postDate)?.let { found.add(m.range.first to it) }
        }

        val gw = giveawayWords.containsMatchIn(s)
        var deadline = found.minByOrNull { it.first }?.second
        // žádné "do …": u soutěží zkusíme libovolné datum blízko data přidání příspěvku
        if (deadline == null && gw) deadline = genericDate(s, today, postDate)
        val user = userRegex.find(text)?.groupValues?.get(1)
            ?: userStartRegex.find(text)?.groupValues?.get(1)
            ?: "?"
        val caption = text.replace(prefixRegex, "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trimEnd('"', '”', '“', '.', ' ')
        return Analysis(gw, deadline, user, caption.take(160), postDate, caption)
    }
}
