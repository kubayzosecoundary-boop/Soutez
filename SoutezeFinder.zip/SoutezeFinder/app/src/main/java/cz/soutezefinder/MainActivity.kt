package cz.soutezefinder

import android.app.Activity
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONTokener
import java.text.Normalizer
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

data class Giveaway(val url: String, val user: String, val deadline: LocalDate?, val snippet: String)

class MainActivity : Activity() {

    private enum class Phase { IDLE, GRID, POST }

    private val MAX_POSTS = 20            // kolik příspěvků se projde (víc = pomalejší a riskantnější)
    private val ui = Handler(Looper.getMainLooper())
    private val fmt = DateTimeFormatter.ofPattern("d. M. yyyy")

    private lateinit var web: WebView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var dateBtn: Button
    private lateinit var adapter: ArrayAdapter<String>

    private var maxEnd: LocalDate? = null
    private var phase = Phase.IDLE
    private var pending = false
    private var runId = 0
    private var queue = ArrayDeque<String>()
    private var total = 0
    private var curHref = ""
    private val shown = mutableListOf<Giveaway>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(32), dp(12), dp(12))
        }

        input = EditText(this).apply {
            hint = "#hashtag nebo slovo (např. soutez)"
            setSingleLine()
        }
        dateBtn = Button(this).apply {
            text = "Konec do: kdykoliv"
            setOnClickListener { pickDate() }
        }
        val searchBtn = Button(this).apply {
            text = "Hledat"
            setOnClickListener { startSearch() }
        }
        val loginBtn = Button(this).apply {
            text = "Instagram / přihlášení"
            setOnClickListener { showWeb() }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(searchBtn, LinearLayout.LayoutParams(0, wrap, 1f))
        row.addView(loginBtn, LinearLayout.LayoutParams(0, wrap, 1f))

        status = TextView(this).apply {
            text = "Nejdřív se přihlas do Instagramu níže, pak hledej."
            setPadding(0, dp(6), 0, dp(6))
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) = pageFinished(url)
            }
        }

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        list = ListView(this).apply {
            setBackgroundColor(Color.WHITE)
            visibility = View.GONE
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(shown[pos].url)))
            }
        }

        val frame = FrameLayout(this)
        frame.addView(web, FrameLayout.LayoutParams(match, match))
        frame.addView(list, FrameLayout.LayoutParams(match, match))

        root.addView(input, LinearLayout.LayoutParams(match, wrap))
        root.addView(dateBtn, LinearLayout.LayoutParams(match, wrap))
        root.addView(row, LinearLayout.LayoutParams(match, wrap))
        root.addView(status, LinearLayout.LayoutParams(match, wrap))
        root.addView(frame, LinearLayout.LayoutParams(match, 0, 1f))
        setContentView(root)

        web.loadUrl("https://www.instagram.com/accounts/login/")
    }

    override fun onDestroy() {
        runId++
        web.destroy()
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun showWeb() {
        runId++               // zastaví případné hledání
        phase = Phase.IDLE
        list.visibility = View.GONE
        status.text = "Přihlas se / zkontroluj Instagram, pak dej Hledat."
        web.loadUrl("https://www.instagram.com/")
    }

    private fun pickDate() {
        val n = maxEnd ?: LocalDate.now()
        DatePickerDialog(this, { _, y, m, d ->
            maxEnd = LocalDate.of(y, m + 1, d)
            dateBtn.text = "Konec do: ${maxEnd!!.format(fmt)}"
        }, n.year, n.monthValue - 1, n.dayOfMonth).apply {
            setButton(DialogInterface.BUTTON_NEUTRAL, "Zrušit filtr") { _, _ ->
                maxEnd = null
                dateBtn.text = "Konec do: kdykoliv"
            }
        }.show()
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun refreshList() {
        val today = LocalDate.now()
        shown.sortWith(compareBy<Giveaway> { it.deadline == null }.thenBy { it.deadline })
        adapter.clear()
        adapter.addAll(shown.map { g ->
            val d = g.deadline
            val head = if (d == null) "📅 termín nenalezen" else {
                val days = ChronoUnit.DAYS.between(today, d)
                val rel = when (days) {
                    0L -> "dnes"
                    1L -> "zítra"
                    else -> "za $days dní"
                }
                "📅 konec ${d.format(fmt)} ($rel)"
            }
            head + "\n@" + g.user + "\n" + g.snippet
        })
        adapter.notifyDataSetChanged()
    }

    // ---------- hledání ----------

    private fun startSearch() {
        val tag = Normalizer.normalize(input.text.toString().trim().removePrefix("#").lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9_]"), "")
        if (tag.isEmpty()) {
            Toast.makeText(this, "Zadej hashtag nebo slovo", Toast.LENGTH_SHORT).show()
            return
        }
        hideKeyboard()
        runId++
        shown.clear()
        refreshList()
        list.visibility = View.VISIBLE
        phase = Phase.GRID
        status.text = "Načítám #$tag …"
        load("https://www.instagram.com/explore/tags/$tag/")
    }

    private fun load(url: String) {
        pending = true
        web.loadUrl(url)
    }

    private fun pageFinished(url: String) {
        if (!pending) return
        pending = false
        if (phase != Phase.IDLE && url.contains("accounts/login")) {
            phase = Phase.IDLE
            list.visibility = View.GONE
            status.text = "Instagram chce přihlášení – přihlas se a pak znovu Hledat."
            return
        }
        val id = runId
        val delay = if (phase == Phase.GRID) 3000L else 2000L
        ui.postDelayed({
            if (id != runId) return@postDelayed
            when (phase) {
                Phase.GRID -> scrollAndCollect(id, 0)
                Phase.POST -> readPost(id)
                Phase.IDLE -> {}
            }
        }, delay)
    }

    private fun scrollAndCollect(id: Int, step: Int) {
        if (step < 4) {
            web.evaluateJavascript("window.scrollTo(0, document.body.scrollHeight);", null)
            status.text = "Načítám výsledky… ${step + 1}/4"
            ui.postDelayed({ if (id == runId) scrollAndCollect(id, step + 1) }, 1500)
            return
        }
        val js = "Array.from(new Set(Array.from(document.querySelectorAll('a[href*=\"/p/\"],a[href*=\"/reel/\"]')).map(function(a){return a.getAttribute('href');})))"
        web.evaluateJavascript(js) { raw ->
            if (id != runId) return@evaluateJavascript
            val links = try {
                val a = JSONArray(raw)
                (0 until a.length()).map { a.getString(it) }
            } catch (e: Exception) {
                emptyList()
            }
            if (links.isEmpty()) {
                phase = Phase.IDLE
                status.text = "Nic nenalezeno. Jsi přihlášený? Zkus jiný hashtag."
                return@evaluateJavascript
            }
            queue = ArrayDeque(links.take(MAX_POSTS))
            total = queue.size
            phase = Phase.POST
            nextPost(id)
        }
    }

    private fun nextPost(id: Int) {
        if (id != runId) return
        if (queue.isEmpty()) {
            phase = Phase.IDLE
            status.text = "Hotovo: ${shown.size} soutěží z $total příspěvků. Klepni na výsledek = otevře se příspěvek."
            return
        }
        curHref = queue.removeFirst()
        status.text = "Čtu příspěvek ${total - queue.size}/$total … (nalezeno ${shown.size})"
        load("https://www.instagram.com$curHref")
    }

    private fun readPost(id: Int) {
        val js = "(function(){var m=document.querySelector('meta[property=\"og:description\"]');" +
            "var t=m?m.getAttribute('content'):'';" +
            "if(!t){var a=document.querySelector('article')||document.body;t=a.innerText.slice(0,1500);}" +
            "return t;})()"
        web.evaluateJavascript(js) { raw ->
            if (id != runId) return@evaluateJavascript
            val text = try {
                JSONTokener(raw).nextValue() as? String
            } catch (e: Exception) {
                null
            } ?: ""
            handleCaption(curHref, text)
            ui.postDelayed({ nextPost(id) }, 1200)
        }
    }

    private fun handleCaption(href: String, text: String) {
        if (text.isBlank()) return
        val today = LocalDate.now()
        val a = DeadlineParser.analyze(text, today)
        if (!a.isGiveaway && a.deadline == null) return
        if (a.deadline != null && a.deadline.isBefore(today)) return          // už skončilo
        val limit = maxEnd
        if (limit != null && (a.deadline == null || a.deadline.isAfter(limit))) return
        shown.add(Giveaway("https://www.instagram.com$href", a.user, a.deadline, a.snippet))
        refreshList()
    }
}
