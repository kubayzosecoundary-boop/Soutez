package cz.soutezefinder

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.concurrent.ConcurrentHashMap

data class Giveaway(
    val url: String,
    val user: String,
    val deadline: LocalDate,
    val snippet: String,
    val img: String
)

class MainActivity : Activity() {

    private enum class Phase { IDLE, GRID, POST }

    private val MAX_POSTS = 20
    private val REQ_PHOTO = 42
    private val ui = Handler(Looper.getMainLooper())
    private val fmt = DateTimeFormatter.ofPattern("d. M. yyyy")
    private val cache = ConcurrentHashMap<String, Bitmap>()

    private lateinit var web: WebView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var listView: ListView
    private lateinit var dateChip: TextView
    private val cardAdapter = CardAdapter()

    private var maxEnd: LocalDate? = null
    private var phase = Phase.IDLE
    private var pending = false
    private var runId = 0
    private var queue = ArrayDeque<String>()
    private var total = 0
    private var curHref = ""
    private val shown = mutableListOf<Giveaway>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // hranatý "blokový" vzhled s ohraničením
    private fun block(color: Int, border: Int) = GradientDrawable().apply {
        setColor(color)
        setStroke(dp(2), border)
        cornerRadius = 0f
    }

    private fun mono(size: Float, color: Int, bold: Boolean = true) = { tv: TextView ->
        tv.textSize = size
        tv.setTextColor(color)
        tv.typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
    }

    private fun tab(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        mono(14f, Color.WHITE)(this)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = block(Color.parseColor("#3A3B3C"), Color.parseColor("#1E1E1F"))
        setOnClickListener { onClick() }
    }

    private fun smallBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        mono(16f, Color.WHITE)(this)
        gravity = Gravity.CENTER
        setPadding(dp(12), 0, dp(12), 0)
        background = block(Color.parseColor("#3A3B3C"), Color.parseColor("#1E1E1F"))
        setOnClickListener { onClick() }
    }

    // pixelový banner (trávník nahoře, hlína dole)
    inner class PixelBanner(ctx: Context) : View(ctx) {
        private val p = Paint()
        private val rnd = java.util.Random(7)
        private val greens = intArrayOf(0xFF5DAA32.toInt(), 0xFF4F9A2A.toInt(), 0xFF6BBB3A.toInt(), 0xFF45882A.toInt())
        private val browns = intArrayOf(0xFF7A5230.toInt(), 0xFF6B4627.toInt(), 0xFF8A5E39.toInt(), 0xFF5E3D20.toInt())
        private val cols = 24
        private val rows = 6
        private val cells = IntArray(cols * rows) { i ->
            if (i / cols < 2) greens[rnd.nextInt(4)] else browns[rnd.nextInt(4)]
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat() / cols
            val h = height.toFloat() / rows
            for (i in cells.indices) {
                p.color = cells[i]
                val x = (i % cols) * w
                val y = (i / cols) * h
                c.drawRect(x, y, x + w + 1, y + h + 1, p)
            }
            p.color = 0x66000000
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bar = Color.parseColor("#2B2B2B")
        window.statusBarColor = bar
        window.navigationBarColor = bar
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val dark = Color.parseColor("#1B1B1B")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
        }

        // ----- banner -----
        val banner = FrameLayout(this)
        banner.addView(PixelBanner(this), FrameLayout.LayoutParams(match, match))
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
        }
        titleBox.addView(TextView(this).apply {
            text = "SOUTĚŽE"
            mono(30f, Color.WHITE)(this)
            setShadowLayer(4f, 3f, 3f, Color.BLACK)
        })
        titleBox.addView(TextView(this).apply {
            text = "Instagram giveawaye, které teprve skončí"
            mono(12f, Color.parseColor("#E0E0E0"), false)(this)
            setShadowLayer(3f, 2f, 2f, Color.BLACK)
        })
        banner.addView(titleBox, FrameLayout.LayoutParams(match, match))
        root.addView(banner, LinearLayout.LayoutParams(match, dp(96)))

        // ----- záložky (hashtagy) -----
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        for (tag in listOf("#soutez", "#giveaway", "#vyhraj", "#soutezim")) {
            tabs.addView(tab(tag) {
                input.setText(tag)
                startSearch()
            }, LinearLayout.LayoutParams(wrap, wrap).apply { rightMargin = dp(8) })
        }
        val tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(bar)
        }
        tabScroll.addView(tabs)
        root.addView(tabScroll, LinearLayout.LayoutParams(match, wrap))

        // ----- vyhledávací pole -----
        input = EditText(this).apply {
            hint = "#hashtag nebo slovo…"
            setSingleLine()
            setHintTextColor(Color.parseColor("#7A7A7A"))
            mono(16f, Color.WHITE, false)(this)
            background = block(Color.parseColor("#313233"), Color.parseColor("#5A5A5A"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val searchRow = LinearLayout(this).apply { setPadding(dp(12), dp(10), dp(12), dp(4)) }
        searchRow.addView(input, LinearLayout.LayoutParams(match, wrap))
        root.addView(searchRow, LinearLayout.LayoutParams(match, wrap))

        status = TextView(this).apply {
            text = "Nejdřív se přihlas do Instagramu (🔑), pak hledej."
            mono(12f, Color.parseColor("#9AA39A"), false)(this)
            setPadding(dp(14), dp(4), dp(14), dp(6))
        }
        root.addView(status, LinearLayout.LayoutParams(match, wrap))

        // ----- web + seznam -----
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) = pageFinished(url)
            }
        }
        listView = ListView(this).apply {
            setBackgroundColor(dark)
            divider = null
            dividerHeight = 0
            visibility = View.GONE
            adapter = cardAdapter
            setOnItemClickListener { _, _, pos, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(shown[pos].url)))
            }
        }
        val frame = FrameLayout(this)
        frame.addView(web, FrameLayout.LayoutParams(match, match))
        frame.addView(listView, FrameLayout.LayoutParams(match, match))
        root.addView(frame, LinearLayout.LayoutParams(match, 0, 1f))

        // ----- spodní lišta s velkým zeleným tlačítkem -----
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bar)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        fun small(v: View) {
            bottom.addView(v, LinearLayout.LayoutParams(wrap, dp(54)).apply { rightMargin = dp(8) })
        }
        small(smallBtn("📷") { pickPhoto() })
        dateChip = smallBtn("📅 vše") { pickDate() }
        small(dateChip)
        small(smallBtn("🔑") { showWeb() })
        bottom.addView(TextView(this).apply {
            text = "▶ HLEDAT"
            mono(20f, Color.WHITE)(this)
            gravity = Gravity.CENTER
            background = block(Color.parseColor("#3C8527"), Color.parseColor("#1D4D13"))
            setOnClickListener { startSearch() }
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        root.addView(bottom, LinearLayout.LayoutParams(match, wrap))

        setContentView(root)
        web.loadUrl("https://www.instagram.com/accounts/login/")
    }

    override fun onDestroy() {
        runId++
        web.destroy()
        super.onDestroy()
    }

    // ---------- karty s výsledky ----------

    inner class CardAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val g = shown[position]
            val today = LocalDate.now()
            val days = ChronoUnit.DAYS.between(today, g.deadline)
            val edge = Color.parseColor("#1E1E1F")
            val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

            val wrapper = FrameLayout(this@MainActivity).apply {
                setPadding(dp(12), dp(5), dp(12), dp(5))
            }
            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                background = block(Color.parseColor("#313233"), edge)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            val iv = ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = block(Color.parseColor("#4A4A4A"), edge)
            }
            card.addView(iv, LinearLayout.LayoutParams(dp(104), dp(104)))
            loadImage(iv, g.img)

            val col = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, 0, 0)
            }
            val rel = when {
                days <= 0L -> "dnes"
                days == 1L -> "zítra"
                else -> "za $days dní"
            }
            val color = when {
                days <= 2L -> "#C0392B"
                days <= 7L -> "#D68910"
                else -> "#3C8527"
            }
            col.addView(TextView(this@MainActivity).apply {
                text = "📅 ${g.deadline.format(fmt)} · $rel"
                mono(12f, Color.WHITE)(this)
                background = block(Color.parseColor(color), edge)
                setPadding(dp(8), dp(3), dp(8), dp(3))
            }, LinearLayout.LayoutParams(wrap, wrap))
            col.addView(TextView(this@MainActivity).apply {
                text = "@" + g.user
                mono(14f, Color.parseColor("#6FCF3F"))(this)
                setPadding(0, dp(6), 0, 0)
            })
            col.addView(TextView(this@MainActivity).apply {
                text = g.snippet
                mono(12f, Color.parseColor("#D0D0D0"), false)(this)
                maxLines = 3
            })
            card.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
            wrapper.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, wrap))
            return wrapper
        }
    }

    private fun loadImage(iv: ImageView, url: String) {
        if (url.isEmpty()) return
        cache[url]?.let {
            iv.setImageBitmap(it)
            return
        }
        iv.tag = url
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                val bmp = conn.inputStream.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp != null) {
                    cache[url] = bmp
                    ui.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun refreshList() {
        shown.sortBy { it.deadline }
        cardAdapter.notifyDataSetChanged()
    }

    // ---------- ovládání ----------

    private fun showWeb() {
        runId++
        phase = Phase.IDLE
        listView.visibility = View.GONE
        status.text = "Přihlas se / zkontroluj Instagram, pak klepni na HLEDAT."
        web.loadUrl("https://www.instagram.com/")
    }

    private fun pickDate() {
        val n = maxEnd ?: LocalDate.now()
        DatePickerDialog(this, { _, y, m, d ->
            maxEnd = LocalDate.of(y, m + 1, d)
            dateChip.text = "📅 ≤ ${maxEnd!!.dayOfMonth}.${maxEnd!!.monthValue}."
        }, n.year, n.monthValue - 1, n.dayOfMonth).apply {
            setButton(DialogInterface.BUTTON_NEUTRAL, "Zrušit filtr") { _, _ ->
                maxEnd = null
                dateChip.text = "📅 vše"
            }
        }.show()
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
    }

    // ---------- hledání podle fotky ----------

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        startActivityForResult(Intent.createChooser(i, "Vyber fotku"), REQ_PHOTO)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == REQ_PHOTO && resultCode == RESULT_OK && uri != null) labelPhoto(uri)
    }

    private fun labelPhoto(uri: Uri) {
        status.text = "Poznávám, co je na fotce…"
        try {
            val image = InputImage.fromFilePath(this, uri)
            val labeler = ImageLabeling.getClient(
                ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build()
            )
            labeler.process(image)
                .addOnSuccessListener { labels ->
                    val best = labels.maxByOrNull { it.confidence }
                    if (best == null) {
                        status.text = "Na fotce jsem nic nepoznal. Zkus jinou."
                    } else {
                        val names = labels.take(3).joinToString(", ") { it.text }
                        input.setText("#" + best.text.lowercase().replace(" ", ""))
                        status.text = "Na fotce: $names"
                        startSearch()
                    }
                }
                .addOnFailureListener {
                    status.text = "Fotku se nepodařilo zpracovat."
                }
        } catch (e: Exception) {
            status.text = "Fotku se nepodařilo otevřít."
        }
    }

    // ---------- hledání ----------

    private fun startSearch() {
        val tag = Normalizer.normalize(input.text.toString().trim().removePrefix("#").lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9_]"), "")
        if (tag.isEmpty()) {
            Toast.makeText(this, "Zadej hashtag nebo slovo", Toast.LENGTH_SHORT).show()
            return
        }
        hideKeyboard()
        runId++
        shown.clear()
        refreshList()
        listView.visibility = View.VISIBLE
        phase = Phase.GRID
        status.text = "Načítám #$tag …"
        load("https://www.instagram.com/explore/tags/$tag/")
    }

    private fun load(url: String) {
        pending = true
        web.loadUrl(url)
    }

    private fun pageFinished(url: String) {
        if (!pending) return
        pending = false
        if (phase != Phase.IDLE && url.contains("accounts/login")) {
            phase = Phase.IDLE
            listView.visibility = View.GONE
            status.text = "Instagram chce přihlášení – přihlas se (🔑) a pak znovu HLEDAT."
            return
        }
        val id = runId
        val delay = if (phase == Phase.GRID) 3000L else 2000L
        ui.postDelayed({
            if (id != runId) return@postDelayed
            when (phase) {
                Phase.GRID -> scrollAndCollect(id, 0)
                Phase.POST -> readPost(id)
                Phase.IDLE -> {}
            }
        }, delay)
    }

    private fun scrollAndCollect(id: Int, step: Int) {
        if (step < 4) {
            web.evaluateJavascript("window.scrollTo(0, document.body.scrollHeight);", null)
            status.text = "Načítám výsledky… ${step + 1}/4"
            ui.postDelayed({ if (id == runId) scrollAndCollect(id, step + 1) }, 1500)
            return
        }
        val js = "Array.from(new Set(Array.from(document.querySelectorAll('a[href*=\"/p/\"],a[href*=\"/reel/\"]')).map(function(a){return a.getAttribute('href');})))"
        web.evaluateJavascript(js) { raw ->
            if (id != runId) return@evaluateJavascript
            val links = try {
                val a = JSONArray(raw)
                (0 until a.length()).map { a.getString(it) }
            } catch (e: Exception) {
                emptyList()
            }
            if (links.isEmpty()) {
                phase = Phase.IDLE
                status.text = "Nic nenalezeno. Jsi přihlášený? Zkus jiný hashtag."
                return@evaluateJavascript
            }
            queue = ArrayDeque(links.take(MAX_POSTS))
            total = queue.size
            phase = Phase.POST
            nextPost(id)
        }
    }

    private fun nextPost(id: Int) {
        if (id != runId) return
        if (queue.isEmpty()) {
            phase = Phase.IDLE
            status.text = "Hotovo: ${shown.size} soutěží z $total příspěvků. Klepni na kartu = otevře příspěvek."
            return
        }
        curHref = queue.removeFirst()
        status.text = "Čtu příspěvek ${total - queue.size}/$total … (nalezeno ${shown.size})"
        load("https://www.instagram.com$curHref")
    }

    private fun readPost(id: Int) {
        val js = """
            (function(){
              var m=document.querySelector('meta[property="og:description"]');
              var t=m?m.getAttribute('content'):'';
              if(!t){var a=document.querySelector('article')||document.body;t=a.innerText.slice(0,1500);}
              var im=document.querySelector('meta[property="og:image"]');
              var src=im?im.getAttribute('content'):'';
              if(!src){var x=document.querySelector('article img');src=x?x.src:'';}
              return JSON.stringify({t:t,i:src});
            })()
        """.trimIndent()
        web.evaluateJavascript(js) { raw ->
            if (id != runId) return@evaluateJavascript
            var text = ""
            var img = ""
            try {
                val s = JSONTokener(raw).nextValue() as? String
                if (s != null) {
                    val o = JSONObject(s)
                    text = o.optString("t")
                    img = o.optString("i")
                }
            } catch (e: Exception) {
            }
            handleCaption(curHref, text, img)
            ui.postDelayed({ nextPost(id) }, 1200)
        }
    }

    private fun handleCaption(href: String, text: String, img: String) {
        if (text.isBlank()) return
        val today = LocalDate.now()
        val a = DeadlineParser.analyze(text, today)
        val dl = a.deadline ?: return                 // bez data konce se neukazuje
        if (!a.isGiveaway) return
        if (dl.isBefore(today)) return                // jen budoucnost
        val limit = maxEnd
        if (limit != null && dl.isAfter(limit)) return
        shown.add(Giveaway("https://www.instagram.com$href", a.user, dl, a.snippet, img))
        refreshList()
    }
}
