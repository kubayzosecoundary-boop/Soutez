package cz.soutezefinder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Služba na popředí: drží aplikaci naživu (a procesor vzhůru), když ji minimalizuješ
 * nebo vypneš displej. Samotné hledání dělá MainActivity.
 */
class SearchService : Service() {

    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val text = intent?.getStringExtra("text") ?: "Hledám soutěže…"
        ensureChannels(this)
        val n = build(this, text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
        if (wl == null) {
            wl = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "soutezefinder:search")
                .apply { acquire(3 * 60 * 60 * 1000L) }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wl?.let { if (it.isHeld) it.release() }
        wl = null
        super.onDestroy()
    }

    companion object {
        private const val CH_RUN = "search_run"
        private const val CH_DONE = "search_done"

        private fun ensureChannels(c: Context) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_RUN, "Probíhající hledání", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_DONE, "Hledání dokončeno", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }

        private fun open(c: Context) = PendingIntent.getActivity(
            c, 0,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        private fun build(c: Context, text: String): Notification =
            Notification.Builder(c, CH_RUN)
                .setContentTitle("Soutěže Finder")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(true)
                .setContentIntent(open(c))
                .build()

        fun start(c: Context, text: String) {
            ensureChannels(c)
            c.startForegroundService(Intent(c, SearchService::class.java).putExtra("text", text))
        }

        fun update(c: Context, text: String) {
            c.getSystemService(NotificationManager::class.java).notify(1, build(c, text))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, SearchService::class.java))
        }

        fun done(c: Context, text: String) {
            ensureChannels(c)
            val n = Notification.Builder(c, CH_DONE)
                .setContentTitle("Hledání dokončeno")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setAutoCancel(true)
                .setContentIntent(open(c))
                .build()
            c.getSystemService(NotificationManager::class.java).notify(2, n)
        }
    }
}
