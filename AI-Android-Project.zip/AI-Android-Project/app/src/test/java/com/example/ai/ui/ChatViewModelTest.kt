package com.example.ai.ui

import com.example.ai.data.ChatMessage
import com.example.ai.data.ChatRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModelTest {
    @Test fun sendAddsUserAndAssistantMessages() = runTest {
        val dispatcher = StandardTestDispatcher(testScheduler)
        Dispatchers.setMain(dispatcher)
        try {
            val repo = object : ChatRepository {
                override suspend fun sendMessage(text: String) = Result.success(ChatMessage("a", "Odpověď", false))
            }
            val vm = ChatViewModel(repo)
            vm.onInputChanged("Ahoj")
            vm.send()
            advanceUntilIdle()
            assertEquals(2, vm.state.value.messages.size)
            assertEquals("", vm.state.value.input)
        } finally { Dispatchers.resetMain() }
    }
}
