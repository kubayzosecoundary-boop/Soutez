package com.example.ai.data

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test

class DemoChatRepositoryTest {
    @Test fun returnsAssistantMessage() = runBlocking {
        val result = DemoChatRepository().sendMessage("Ahoj")
        assertNotNull(result.getOrNull())
        assertFalse(result.getOrThrow().fromUser)
    }
}
