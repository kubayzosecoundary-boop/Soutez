package com.example.ai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.data.ChatMessage
import com.example.ai.data.ChatRepository
import com.example.ai.data.DemoChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val isLoading: Boolean = false,
    val error: String? = null
)

class ChatViewModel(
    private val repository: ChatRepository = DemoChatRepository()
) : ViewModel() {
    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    fun onInputChanged(value: String) { _state.value = _state.value.copy(input = value, error = null) }

    fun send() {
        val text = _state.value.input.trim()
        if (text.isEmpty() || _state.value.isLoading) return
        val userMessage = ChatMessage(UUID.randomUUID().toString(), text, true)
        _state.value = _state.value.copy(
            messages = _state.value.messages + userMessage,
            input = "",
            isLoading = true,
            error = null
        )
        viewModelScope.launch {
            repository.sendMessage(text).fold(
                onSuccess = { answer ->
                    _state.value = _state.value.copy(messages = _state.value.messages + answer, isLoading = false)
                },
                onFailure = { error ->
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = error.message ?: "Odpověď se nepodařilo načíst."
                    )
                }
            )
        }
    }

    fun newChat() { _state.value = ChatUiState() }
    fun dismissError() { _state.value = _state.value.copy(error = null) }
}
