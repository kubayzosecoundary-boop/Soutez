package com.example.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.data.ChatMessage
import com.example.ai.ui.theme.*
import java.util.Locale

@Composable
fun AiApp(vm: ChatViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    var settingsOpen by remember { mutableStateOf(false) }
    var voiceEnabled by remember { mutableStateOf(true) }
    var selectedVoice by remember { mutableStateOf("Výchozí hlas systému") }
    var speechRate by remember { mutableFloatStateOf(1f) }

    Scaffold(containerColor = CyberBlack, topBar = {
        TopAppBar(
            title = { Column { Text("AI", color = NeonRed); Text("LEHKÝ AI ASISTENT", style = MaterialTheme.typography.labelSmall, color = MutedText) } },
            actions = {
                IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "Nový chat", tint = NeonRed) }
                IconButton(onClick = { settingsOpen = !settingsOpen }) { Icon(Icons.Default.Settings, "Nastavení", tint = NeonRed) }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = CyberBlack)
        )
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(CyberBlack)) {
            if (settingsOpen) {
                SettingsPanel(
                    voiceEnabled, { voiceEnabled = it }, selectedVoice, { selectedVoice = it },
                    speechRate, { speechRate = it }
                )
            } else {
                ChatPanel(state, vm, voiceEnabled, selectedVoice, speechRate)
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    voiceEnabled: Boolean, onVoiceEnabled: (Boolean) -> Unit,
    selectedVoice: String, onVoice: (String) -> Unit,
    rate: Float, onRate: (Float) -> Unit
) {
    val context = LocalContext.current
    var availableVoices by remember { mutableStateOf(listOf("Výchozí hlas systému")) }
    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val voices = engine?.voices.orEmpty().filter { it.locale.language == "cs" || it.locale.language == "en" }
                    .map { it.name }.distinct()
                if (voices.isNotEmpty()) availableVoices = listOf("Výchozí hlas systému") + voices
            }
        }
        onDispose { engine?.shutdown() }
    }
    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("NASTAVENÍ HLASU", color = NeonRed, style = MaterialTheme.typography.titleLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mluvené odpovědi", color = TextWhite, modifier = Modifier.weight(1f))
            Switch(checked = voiceEnabled, onCheckedChange = onVoiceEnabled, colors = SwitchDefaults.colors(checkedThumbColor = NeonRed))
        }
        Text("Hlas", color = TextWhite)
        availableVoices.forEach { voice ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = selectedVoice == voice, onClick = { onVoice(voice) }, colors = RadioButtonDefaults.colors(selectedColor = NeonRed))
                Text(voice, color = TextWhite)
            }
        }
        Text("Rychlost řeči: ${"%.1f".format(rate)}×", color = TextWhite)
        Slider(value = rate, onValueChange = onRate, valueRange = 0.7f..1.4f, colors = SliderDefaults.colors(thumbColor = NeonRed, activeTrackColor = NeonRed))
        Text("Dostupné hlasy závisí na hlasovém enginu a jazycích nainstalovaných v telefonu.", color = MutedText, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ChatPanel(state: ChatUiState, vm: ChatViewModel, voiceEnabled: Boolean, voiceName: String, rate: Float) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }
    LaunchedEffect(state.messages.lastOrNull()?.id, voiceEnabled, voiceName, rate, ttsReady) {
        val last = state.messages.lastOrNull()
        if (last != null && !last.fromUser && voiceEnabled && ttsReady) {
            val engine = tts ?: return@LaunchedEffect
            engine.setSpeechRate(rate)
            if (voiceName != "Výchozí hlas systému") {
                engine.voices?.firstOrNull { it.name == voiceName }?.let { engine.voice = it }
            }
            engine.speak(last.text, TextToSpeech.QUEUE_FLUSH, null, last.id)
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (state.messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("AI", style = MaterialTheme.typography.displayLarge, color = NeonRed)
                Text("Čím ti dnes mohu pomoci?", color = TextWhite)
                Text("Napiš zprávu nebo použij mikrofon.", color = MutedText)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state.messages, key = { it.id }) { MessageBubble(it) }
                if (state.isLoading) item { Text("AI přemýšlí…", color = NeonRed) }
            }
        }
        state.error?.let {
            Text(it, color = NeonRed, modifier = Modifier.padding(horizontal = 16.dp))
        }
        Composer(state.input, vm::onInputChanged, vm::send)
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(color = if (message.fromUser) NeonRed.copy(alpha = .18f) else Panel, shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (message.fromUser) NeonRed.copy(alpha = .55f) else BorderRed), modifier = Modifier.widthIn(max = 310.dp)) {
            Text(message.text, color = TextWhite, modifier = Modifier.padding(14.dp))
        }
    }
}

@Composable
private fun Composer(value: String, onChange: (String) -> Unit, onSend: () -> Unit) {
    val context = LocalContext.current
    var listening by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeech(context) { onChange(it); listening = false }
        else listening = false
    }
    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = value, onValueChange = onChange, modifier = Modifier.weight(1f),
            placeholder = { Text("Napiš zprávu…", color = MutedText) },
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeonRed, unfocusedBorderColor = BorderRed),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }), maxLines = 4
        )
        IconButton(onClick = {
            listening = true
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startSpeech(context) { onChange(it); listening = false }
            } else permission.launch(Manifest.permission.RECORD_AUDIO)
        }) { Icon(Icons.Default.Mic, "Hlasový vstup", tint = if (listening) NeonRed else TextWhite) }
        IconButton(onClick = onSend) { Icon(Icons.Default.Send, "Odeslat", tint = NeonRed) }
    }
}

private fun startSpeech(context: android.content.Context, onResult: (String) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onResults(results: android.os.Bundle?) {
            results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onResult)
            recognizer.destroy()
        }
        override fun onError(error: Int) { recognizer.destroy() }
        override fun onReadyForSpeech(params: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
    })
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Mluv…")
    }
    recognizer.startListening(intent)
}
