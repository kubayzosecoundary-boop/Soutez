package com.example.ai.data

data class ChatMessage(
    val id: String,
    val text: String,
    val fromUser: Boolean,
    val createdAt: Long = System.currentTimeMillis()
)
