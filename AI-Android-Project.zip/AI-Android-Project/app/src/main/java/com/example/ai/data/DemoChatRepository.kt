package com.example.ai.data

import kotlinx.coroutines.delay
import java.util.UUID

/**
 * Offline demo repository. Replace with a backend-backed implementation before production.
 * Never place a model-provider secret/API key in the Android application.
 */
class DemoChatRepository : ChatRepository {
    override suspend fun sendMessage(text: String): Result<ChatMessage> = runCatching {
        delay(450)
        val reply = "Jsem demo režim aplikace AI. Připoj bezpečný AI backend a budu moci odpovídat na: “$text”"
        ChatMessage(UUID.randomUUID().toString(), reply, fromUser = false)
    }
}
