package com.example.ai.data

interface ChatRepository {
    suspend fun sendMessage(text: String): Result<ChatMessage>
}
