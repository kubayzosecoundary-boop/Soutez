package com.example.ai.data

import com.google.firebase.FirebaseApp

/** Firebase is optional during local development. Add google-services.json and initialize it
 * using the Google Services Gradle plugin when configuring your own Firebase project. */
object FirebaseStatus {
    fun isConfigured(): Boolean = runCatching { FirebaseApp.getInstance() }.isSuccess
}
