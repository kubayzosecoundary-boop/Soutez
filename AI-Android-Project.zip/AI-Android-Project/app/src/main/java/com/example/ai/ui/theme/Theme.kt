package com.example.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CyberBlack = Color(0xFF09090D)
val Panel = Color(0xFF17131A)
val NeonRed = Color(0xFFFF3152)
val BorderRed = Color(0xFF642638)
val TextWhite = Color(0xFFF5F1F3)
val MutedText = Color(0xFF9B9299)

private val CyberScheme = darkColorScheme(
    primary = NeonRed, onPrimary = Color.White,
    background = CyberBlack, onBackground = TextWhite,
    surface = Panel, onSurface = TextWhite,
    secondary = Color(0xFFFF667D)
)

@Composable
fun AiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CyberScheme, content = content)
}
