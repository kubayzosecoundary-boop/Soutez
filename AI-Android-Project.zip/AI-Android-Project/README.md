# AI – Android starter project

Odlehčená česká AI chat aplikace pro Android. Kotlin, Jetpack Compose, MVVM a oddělená datová vrstva.

## Co je připraveno
- Tmavé cyberpunk/neon-red UI.
- Chat UI, stavové řízení přes ViewModel a offline demo repository.
- Hlasový vstup přes Android SpeechRecognizer (vyžaduje oprávnění mikrofonu).
- Čtení odpovědí přes Android TextToSpeech, výběr dostupného systémového hlasu a rychlosti.
- Firebase Auth/Firestore závislosti a kontrola, zda je Firebase nakonfigurovaný.
- Jednotkové testy pro repository a ViewModel.

## Požadavky
- Android Studio s podporou Android Gradle Plugin 8.13.x
- JDK 17
- Android SDK Platform 36
- Zařízení/emulátor Android 15 (API 35) nebo novější

## Spuštění
1. Rozbal projekt a otevři složku `AI-Android-Project` v Android Studiu.
2. Nech Gradle dokončit synchronizaci.
3. Spusť konfiguraci `app` na zařízení/emulátoru s API 35+.
4. V demo režimu funguje UI a hlasové funkce; odpovědi jsou záměrně ukázkové.

## Firebase konfigurace
1. Vytvoř projekt ve Firebase Console a přidej Android aplikaci s package name `com.example.ai`.
2. Stáhni `google-services.json` do složky `app/`.
3. Přidej Google Services plugin do `plugins` v root `build.gradle.kts` a v `app/build.gradle.kts`, podle aktuální dokumentace Firebase.
4. Zapni požadované Firebase produkty (např. Authentication a Cloud Firestore), nastav pravidla Firestore a ověř přihlášení.
5. V produkční implementaci inicializuj Firebase až po dodání konfigurace a doplň repository pro synchronizaci historie.

Firebase SDK je přidané, ale tento starter záměrně nevyžaduje Firebase konfiguraci pro lokální spuštění.

## Připojení skutečného AI modelu
`DemoChatRepository` je offline náhrada. Pro skutečné odpovědi vytvoř HTTPS backend (např. Firebase Cloud Functions / Cloud Run), který:
- ověří Firebase ID token uživatele,
- aplikuje limity a ochranu proti zneužití,
- bezpečně načte API klíč z Secret Manageru,
- zavolá vybraného poskytovatele modelu,
- vrátí normalizovanou odpověď aplikaci.

Nikdy nevkládej tajný klíč poskytovatele AI do APK, `BuildConfig`, repozitáře ani veřejného Firebase nastavení. Poté implementuj `ChatRepository`, který volá vlastní backend, a předej jej do `ChatViewModel`.

## Architektura
- `data/`: model zprávy, repository kontrakt a demo implementace.
- `ui/`: Compose obrazovky a `ChatViewModel`.
- `ui/theme/`: barvy a Material 3 téma.

## Testy
Spusť `./gradlew test` nebo v Android Studiu úlohu `app > Tasks > verification > test`.

## Produkční checklist
Před vydáním doplň autentizaci a bezpečnostní pravidla, backend pro AI, perzistenci a synchronizaci historie, ochranu soukromí, limity, monitoring, přístupnost, lokalizaci, testy na reálných zařízeních a zásady ochrany osobních údajů. Aktuální starter není plnohodnotnou náhradou všech funkcí ChatGPT.
